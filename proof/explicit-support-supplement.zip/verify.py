from itertools import product

def check(n=2, k=1):
    pairs = [(1 << (2*i), 1 << (2*i+1)) for i in range(n)]
    full = (1 << (2*n)) - 1
    support = [(0, 1, n-1)] + [(full ^ (1 << i), 0, 1) for i in range(2*n)]
    all_rows = list(product(range(full+1), range(2), range(2), range(1<<k)))
    def holds(term, h, s):
        return (term & full & h) == (term & full) and (term <= full or s)
    for table in range(1 << (1 << (n+k))):
        def f(x,y):
            return (table >> ((x << k) | y)) & 1
        def obs(h,s,u,y):
            x = sum(bool(h & a) << i for i,(a,b) in enumerate(pairs))
            return s or u or (all(h & (a|b) for a,b in pairs) and
                               (any(h & (a|b) == (a|b) for a,b in pairs) or f(x,y)))
        def solution(t):
            mass = sum(w for h,s,w in support if holds(t,h,s))
            return mass if mass and all(not holds(t,h,s) or obs(h,s,u,y)
                                        for h,s,u,y in all_rows) else 0
        anchor = solution(full+1)
        assert anchor == n-1
        better = max(map(solution, range(2*(full+1)))) > anchor
        target = any(all(f(x,y) for y in range(1<<k)) for x in range(1<<n))
        assert better == target, table
    print("All 256 matrices passed for n=2, k=1.")
check()

