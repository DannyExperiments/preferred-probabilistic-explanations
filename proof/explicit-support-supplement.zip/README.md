# Q800 explicit-support supplement

Start with PROOF.md. The new proof covers a fully specified distribution and a tautological theory, as distinct from the original proof with one assigned event. The fixed-support-size classification is an optional companion. Run `python3 verify.py` for the small-case replay.

